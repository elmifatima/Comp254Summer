package org.example;

import com.sun.source.tree.Tree;

public class Exercise2BinaryTreeHeight {

    private TreeNode root;

    // Inner class nodes
    private class TreeNode {
        int element;
        TreeNode left;
        TreeNode right;

        // Constructor
        TreeNode(int element) {
            this.element = element;
        }
    }

    // Create method for binarytree data
    public void createBinaryTree() {
        TreeNode first = new TreeNode(50);
        TreeNode second = new TreeNode(40);
        TreeNode third = new TreeNode(45);
        TreeNode fourth = new TreeNode(30);

        root = first;
        first.left = second;
        first.right = third;
        second.left = fourth;
    }

    // print method height postorder
    public void printNodeHeight() {
        computeHeight(root);
    }

    //Postodrder recursive helper to print height/ each node
    private int computeHeight(TreeNode node) {
        if (node == null)
            return -1;  // base case leaf node has 0 height

        int leftHeight = computeHeight(node.left);
        int rightHeight = computeHeight(node.right);

        int currentHeight = 1 + Math.max(leftHeight, rightHeight);

        System.out.println("Node " + node.element + " has subtree height of: " + currentHeight);
        return currentHeight;
    }

    // Display a diagram of the tree
    private void prettyDisplay(TreeNode node, int level) {
        if (node == null) {
            return;

        }
        prettyDisplay(node.right, level + 1);

        // print indentation
        for (int i = 0; i < level - 1; i++) {
            System.out.print("|\t");
        }
        if (level != 0) {
            System.out.println("|------->" + node.element);
        } else {
            System.out.println(node.element);
        }
        prettyDisplay(node.left, level + 1);

    }


    // Method to Test code
    public static void main(String[] args) {
        Exercise2BinaryTreeHeight myHeighttree = new Exercise2BinaryTreeHeight();
        myHeighttree.createBinaryTree();

        // post order method left right then parent calling commute recursive method
        myHeighttree.printNodeHeight();

        // print tree structure
        System.out.println("\ntree structure: ");

        // method to visually display diagram structure
        myHeighttree.prettyDisplay(myHeighttree.root, 0);

    }

}