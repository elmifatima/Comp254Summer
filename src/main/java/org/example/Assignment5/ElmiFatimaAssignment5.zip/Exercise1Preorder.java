package org.example;

public class Exercise1Preorder {
    public static class BinaryTree {

        private TreeNode root;

        private class TreeNode {
            private TreeNode left;
            private TreeNode right;
            private int data; // Generic type
            private TreeNode parent;

            // Constructor
            public TreeNode(int data) {
                this.data = data;
            }
        }


        // Method to create the binarytree   O(1) runs fixed number of times to create node
        public void createBinaryTree() {
            TreeNode first = new TreeNode(15);
            TreeNode second = new TreeNode(9);
            TreeNode third = new TreeNode(6);
            TreeNode fourth = new TreeNode(2);


            root = first; // ---> first
            first.left = second; // --->second
            first.right = third; // second <--- first ---> third

            second.parent = first;
            third.parent = first;

            second.left = fourth;
            fourth.parent = second;

        }

        // PreOrder method  O(n) visits each node recursively once
        public void preOrder(TreeNode root) {
            if (root == null) {
                return;
            }
            System.out.println(root.data + " ");
            preOrder(root.left);
            preOrder(root.right);

        }

        // method for pointer find successor of p   O(h)
        public TreeNode preorderNext(TreeNode p) {
            if (p.left != null) {
                return p.left;
            }
            if (p.right != null) {
                return p.right;
            }

            TreeNode current = p;
            while (current.parent != null) {
                if (current == current.parent.left && current.parent.right != null) {
                    return current.parent.right;
                }
                current = current.parent;
            }
            return null;  // last node p
        }


        // method to print traversal position with numbers O(n) very one n times
        public void printPreorderWithPosition() {
            printPreorderWithPosition(root, new int[]{1});
        }


        // print preorder position

        private void printPreorderWithPosition(TreeNode node, int[] position){
            if(node == null)
                return;

            System.out.println(" Position " + position[0] + " we have" +  ":" + node.data);
            position[0]++;
            printPreorderWithPosition(node.left, position);
            printPreorderWithPosition(node.right, position);
        }



        // Method to get preorder positon of node O(n) searches every node
        private int getPreorderIndexHelper(TreeNode current, TreeNode target, int[] index) {
            if (current == null)
                return -1;

            if (current == target)
                return index[0];

            index[0]++;
            int left = getPreorderIndexHelper(current.left, target, index);
            if (left != -1) return left;

            index[0]++;
            return getPreorderIndexHelper(current.right, target, index);
        }


        // Method for testing code

        public static void main(String[] args) {
            BinaryTree bt = new BinaryTree();
            bt.createBinaryTree();

            System.out.print("Preorder traversal: ");
            bt.preOrder(bt.root);
            System.out.println();

            //third node in traversal
            TreeNode p = bt.root.left.left; // Node 4
            TreeNode next = bt.preorderNext(p);

            //last node in preorder
            TreeNode p2 = bt.root.right;
            TreeNode next2 = bt.preorderNext(p2);

            // print traversal with position
            System.out.println("Preorder traversal with positon: ");
            bt.printPreorderWithPosition();
            System.out.println();


            //preorder position
            int positionOfp = bt.getPreorderIndexHelper(bt.root, p, new int[] {1});
            int positionOfNext = next !=null ? bt.getPreorderIndexHelper(bt.root, next, new int[]{1}) : -1;

            System.out.println(" Node  "   +  p.data + " is @ position "  +  positionOfp  + "in preorder.");

            if (next != null) {
                System.out.println("Preorder successor of " + p.data + " is: " + next.data);
            } else {
                System.out.println("Node  "  + p.data + " has no preorder successor.");
            }
        }

    }
}
