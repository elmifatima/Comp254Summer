package org.example;

public class Exercise3UpHeap {

    private static final int DEFAULT_CAPACITY = 10;
    private Entry[] heap;
    private int size = 0;

    //class for keys
    private class Entry {
        int key;
        String value;

        //Constractor
        Entry(int key, String value) {
            this.key = key;
            this.value = value;
        }

        //ToString method
        public String toString() {
            return "(" + key + ", " + value + ")";
        }
    }
        public Exercise3UpHeap() {
            heap = new Entry[DEFAULT_CAPACITY];
        }

        //Insert new entry
        public void insert(int key, String value){
            ensureCapacity();
            Entry newEntry = new Entry(key, value);
            heap[size] = newEntry;
            upheap(size);
            size++;
        }

        //recursive method to restore order
        private void upheap(int index){
            if (index == 0)
                return; //base case

            int parentIndex = (index -1) /2;

            if(heap[index].key < heap[parentIndex].key){
                swap(index, parentIndex);
                upheap(parentIndex); // recursive upward
            }
        }

        // Remove and return minimum entry
        public Entry removeMin(){
            if(isEmpty())
                return null;

            Entry min = heap[0];
            heap[0] = heap[size -1];
            size--;
            downheap(0);
            return min;
        }

        // recursive downheap method to check left & right child
        private void downheap(int index){
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            int minimum = index;

            if (left < size && heap[left].key < heap[minimum].key)
                minimum = left;

            if (right < size && heap[right].key < heap[minimum].key)
                minimum = right;

            if ( minimum != index){
                swap(index, minimum);
                downheap(minimum);
            }
        }

        private void swap(int i, int j){
            Entry temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        private boolean isEmpty(){
            return size ==0;
        }

        // method to double the size of array
        private void ensureCapacity(){
            if(size == heap.length){
                Entry[] newHeap = new Entry[2 * heap.length];
                System.arraycopy(heap, 0, newHeap, 0,heap.length);
                heap = newHeap;
            }
        }

        // print heap array
        public void printHeap(){
            System.out.println("Heap contents:");
            for(int i = 0; i < size; i++){
                System.out.println(heap[i] + " ");
            }
            System.out.println();
        }


        //additional method to show diagram of heap as tree
    public void printTree(){
        printTreeHelper(0,0);
    }
    private void printTreeHelper(int index, int level){
        if(index >= size)
            return;

        //on top is right child
        int right = 2 * index +2;
        printTreeHelper(right, level +1);

        // print current node
        for(int i = 0; i < level; i ++){
            System.out.print("|\t");
        }
        System.out.println("|--" + heap[index]);

        // on top left child
        int left = 2 * index +1;
        printTreeHelper(left, level +1);
    }

        // Test method
        public static void main(String[] args) {
            Exercise3UpHeap priorityQ = new Exercise3UpHeap();

            priorityQ.insert(4, "Four");
            priorityQ.insert(2, "Two");
            priorityQ.insert(5, "Five");
            priorityQ.insert(1, "One");
            priorityQ.insert(3, "Three");
            priorityQ.printHeap();

            //display heap diagram
            priorityQ.printHeap(); // original array form
            priorityQ.printTree(); // diagram form

        }
    }

//    public void upheap(int index) {
//        if (index == 0) return; // Base case
//        int parent = parent(index); // Find the parent index
//        if (compare(data[index], data[parent])) // Check if the current element is smaller than its parent
//            swap(index, parent); // Swap the elements
//        upheapRecursive(parent); // Recur on the parent index
//        upheapRecursive(index); // Recur on the current index
//    }

